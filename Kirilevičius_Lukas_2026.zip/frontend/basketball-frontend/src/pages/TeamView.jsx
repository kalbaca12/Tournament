import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { teamsApi } from "../api/teams";
import { playersApi } from "../api/players";
import { useAuth } from "../auth/useAuth";
import EmptyState from "../components/EmptyState";
import { useConfirm } from "../components/useConfirm";
import { useToast } from "../components/useToast";

function formatDateTime(value) {
  if (!value) return "No time";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString();
}

function resolveTeamName(matchRow, side) {
  const relationCamel = side === "home" ? "homeTeam" : "awayTeam";
  const relationSnake = side === "home" ? "home_team" : "away_team";
  const idKey = side === "home" ? "home_team_id" : "away_team_id";

  return (
    matchRow?.[relationCamel]?.name ||
    matchRow?.[relationSnake]?.name ||
    (matchRow?.[idKey] ? `Team ${matchRow[idKey]}` : "TBD")
  );
}

export default function TeamView() {
  const { id } = useParams();
  const nav = useNavigate();
  const { isManager, user } = useAuth();
  const { confirm } = useConfirm();
  const { showToast } = useToast();
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [matches, setMatches] = useState([]);
  const [form, setForm] = useState({ name: "", city: "", logo_url: "" });
  const [newPlayer, setNewPlayer] = useState({ first_name: "", last_name: "", photo_url: "", jersey_number: "" });
  const [editRows, setEditRows] = useState({});
  const [err, setErr] = useState("");
  const [saving, setSaving] = useState(false);

  const canManageTeam = useMemo(() => {
    if (!isManager || !team || !user) return false;
    return Number(team.manager_id) === Number(user.id);
  }, [isManager, team, user]);

  const groupedMatches = useMemo(() => {
    const bucket = {};
    for (const m of matches) {
      const dayKey = m.scheduled_at ? m.scheduled_at.slice(0, 10) : "Unscheduled";
      if (!bucket[dayKey]) bucket[dayKey] = [];
      bucket[dayKey].push(m);
    }
    return Object.entries(bucket).sort(([a], [b]) => {
      if (a === "Unscheduled") return 1;
      if (b === "Unscheduled") return -1;
      return a.localeCompare(b);
    });
  }, [matches]);

  const load = useCallback(async () => {
    const [teamRes, playersRes, matchesRes] = await Promise.all([
      teamsApi.get(id),
      playersApi.list(id),
      teamsApi.matches(id),
    ]);

    setTeam(teamRes.data);
    setForm({
      name: teamRes.data?.name || "",
      city: teamRes.data?.city || "",
      logo_url: teamRes.data?.logo_url || "",
    });
    setPlayers(playersRes.data || []);
    setMatches(matchesRes.data || []);
  }, [id]);

  useEffect(() => {
    load().catch((e) => setErr(e?.response?.data?.message || e.message));
  }, [load]);

  const save = async () => {
    if (!canManageTeam) return;
    setErr("");
    setSaving(true);
    try {
      const res = await teamsApi.update(id, {
        ...form,
        logo_url: form.logo_url.trim() || null,
      });
      setTeam({ ...team, ...res.data });
      showToast("Team details saved.");
    } catch (e) {
      const message = e?.response?.data?.message || JSON.stringify(e?.response?.data) || e.message;
      setErr(message);
      showToast(message, "error");
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!canManageTeam) return;
    const ok = await confirm({
      title: "Delete this team?",
      message: "This removes the team and can affect tournament registration data.",
      confirmLabel: "Delete team",
    });
    if (!ok) return;
    setErr("");
    try {
      await teamsApi.remove(id);
      showToast("Team deleted.");
      nav("/teams");
    } catch (e) {
      const message = e?.response?.data?.message || JSON.stringify(e?.response?.data) || e.message;
      setErr(message);
      showToast(message, "error");
    }
  };

  const addPlayer = async () => {
    if (!canManageTeam) return;
    setErr("");
    const livePlayer = {
      first_name: document.querySelector('input[placeholder="First name"]')?.value ?? newPlayer.first_name,
      last_name: document.querySelector('input[placeholder="Last name"]')?.value ?? newPlayer.last_name,
      photo_url: document.querySelector('input[placeholder="Photo URL"]')?.value ?? newPlayer.photo_url,
      jersey_number: document.querySelector('input[placeholder="Jersey"]')?.value ?? newPlayer.jersey_number,
    };
    try {
      await playersApi.create({
        team_id: Number(id),
        first_name: livePlayer.first_name,
        last_name: livePlayer.last_name,
        photo_url: livePlayer.photo_url.trim() || null,
        jersey_number: livePlayer.jersey_number === "" ? null : Number(livePlayer.jersey_number),
      });
      setNewPlayer({ first_name: "", last_name: "", photo_url: "", jersey_number: "" });
      await load();
      showToast("Player added.");
    } catch (e) {
      const message = e?.response?.data?.message || JSON.stringify(e?.response?.data) || e.message;
      setErr(message);
      showToast(message, "error");
    }
  };

  const startEditPlayer = (p) => {
    setEditRows((prev) => ({
      ...prev,
      [p.id]: {
        first_name: p.first_name || "",
        last_name: p.last_name || "",
        photo_url: p.photo_url || "",
        jersey_number: p.jersey_number ?? "",
      },
    }));
  };

  const savePlayer = async (playerId) => {
    if (!canManageTeam) return;
    const row = editRows[playerId];
    if (!row) return;

    setErr("");
    try {
      await playersApi.update(playerId, {
        first_name: row.first_name,
        last_name: row.last_name,
        photo_url: row.photo_url.trim() || null,
        jersey_number: row.jersey_number === "" ? null : Number(row.jersey_number),
      });

      setEditRows((prev) => {
        const next = { ...prev };
        delete next[playerId];
        return next;
      });
      await load();
      showToast("Player saved.");
    } catch (e) {
      const message = e?.response?.data?.message || JSON.stringify(e?.response?.data) || e.message;
      setErr(message);
      showToast(message, "error");
    }
  };

  const deletePlayer = async (playerId) => {
    if (!canManageTeam) return;
    const ok = await confirm({
      title: "Delete this player?",
      message: "This removes the player from the roster.",
      confirmLabel: "Delete player",
    });
    if (!ok) return;
    setErr("");
    try {
      await playersApi.remove(playerId);
      await load();
      showToast("Player deleted.");
    } catch (e) {
      const message = e?.response?.data?.message || JSON.stringify(e?.response?.data) || e.message;
      setErr(message);
      showToast(message, "error");
    }
  };

  if (err) return <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{err}</div>;
  if (!team) return <div className="text-slate-500">Loading...</div>;

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Team details</h1>
        <p className="text-sm text-slate-500">Team ID: {team.id}</p>
      </div>

      <div className="panel space-y-4 p-5">
        {canManageTeam ? (
          <>
            <input
              className="input"
              placeholder="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <input
              className="input"
              placeholder="City"
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
            />
            <input
              className="input"
              placeholder="Logo URL"
              value={form.logo_url}
              onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
            />
          </>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {team.logo_url ? (
              <img className="team-detail-logo" src={team.logo_url} alt={`${team.name} logo`} />
            ) : null}
            <div>
              <div className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Name</div>
              <div className="mt-1 text-base font-semibold text-slate-900">{team.name || "Unnamed team"}</div>
            </div>
            <div>
              <div className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">City</div>
              <div className="mt-1 text-base font-semibold text-slate-900">{team.city || "N/A"}</div>
            </div>
          </div>
        )}

        {canManageTeam && (
          <div className="flex flex-wrap gap-2">
            <button onClick={save} disabled={saving} className="btn-primary disabled:opacity-60">
              {saving ? "Saving..." : "Save changes"}
            </button>
            <button onClick={remove} className="btn-danger">Delete team</button>
          </div>
        )}
      </div>

      <div className="panel space-y-4 p-5">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Players</h2>
          <p className="text-sm text-slate-500">Roster for this team.</p>
        </div>

        {canManageTeam && (
          <div className="grid grid-cols-1 gap-2 md:grid-cols-5">
            <input
              className="input"
              placeholder="First name"
              value={newPlayer.first_name}
              onChange={(e) => setNewPlayer({ ...newPlayer, first_name: e.target.value })}
            />
            <input
              className="input"
              placeholder="Last name"
              value={newPlayer.last_name}
              onChange={(e) => setNewPlayer({ ...newPlayer, last_name: e.target.value })}
            />
            <input
              className="input"
              placeholder="Photo URL"
              value={newPlayer.photo_url}
              onChange={(e) => setNewPlayer({ ...newPlayer, photo_url: e.target.value })}
            />
            <input
              className="input"
              type="number"
              min={0}
              max={99}
              placeholder="Jersey"
              value={newPlayer.jersey_number}
              onChange={(e) => setNewPlayer({ ...newPlayer, jersey_number: e.target.value })}
            />
            <button onClick={addPlayer} className="btn-primary">Add player</button>
          </div>
        )}

        <div className="grid gap-2">
          {players.map((p) => {
            const row = editRows[p.id];
            const isEditing = Boolean(row);

            return (
              <div key={p.id} className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                {!isEditing ? (
                  <div className="flex items-center justify-between gap-2">
                    <Link to={`/players/${p.id}`} className="flex min-w-0 items-center gap-3 rounded-md transition hover:text-sky-700">
                      {p.photo_url ? (
                        <img className="player-avatar" src={p.photo_url} alt={`${p.first_name} ${p.last_name}`} />
                      ) : null}
                      <div className="min-w-0">
                      <div className="font-medium text-slate-900">{p.first_name} {p.last_name}</div>
                      <div className="text-sm text-slate-500">Jersey #{p.jersey_number ?? "-"}</div>
                      </div>
                    </Link>
                    {canManageTeam && (
                      <div className="flex gap-2">
                        <button onClick={() => startEditPlayer(p)} className="btn-secondary">Edit</button>
                        <button onClick={() => deletePlayer(p.id)} className="btn-danger">Delete</button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-2 md:grid-cols-5">
                    <input
                      className="input"
                      value={row.first_name}
                      onChange={(e) => setEditRows((prev) => ({ ...prev, [p.id]: { ...prev[p.id], first_name: e.target.value } }))}
                    />
                    <input
                      className="input"
                      value={row.last_name}
                      onChange={(e) => setEditRows((prev) => ({ ...prev, [p.id]: { ...prev[p.id], last_name: e.target.value } }))}
                    />
                    <input
                      className="input"
                      value={row.photo_url}
                      placeholder="Photo URL"
                      onChange={(e) => setEditRows((prev) => ({ ...prev, [p.id]: { ...prev[p.id], photo_url: e.target.value } }))}
                    />
                    <input
                      className="input"
                      type="number"
                      min={0}
                      max={99}
                      value={row.jersey_number}
                      onChange={(e) => setEditRows((prev) => ({ ...prev, [p.id]: { ...prev[p.id], jersey_number: e.target.value } }))}
                    />
                    <div className="flex gap-2">
                      <button onClick={() => savePlayer(p.id)} className="btn-primary">Save</button>
                      <button
                        onClick={() => setEditRows((prev) => {
                          const next = { ...prev };
                          delete next[p.id];
                          return next;
                        })}
                        className="btn-secondary"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          {players.length === 0 && (
            <EmptyState
              title="No players yet"
              description={canManageTeam ? "Add the first player above to build this roster." : "This team has not published any roster players yet."}
            />
          )}
        </div>
      </div>

      <div className="panel space-y-3 p-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Matches</h2>
          <p className="text-sm text-slate-500">Matches for this team, grouped by day.</p>
        </div>

        {groupedMatches.length === 0 ? (
          <EmptyState
            title="No matches yet"
            description="This team does not have any generated or manually created matches yet."
          />
        ) : (
          <div className="space-y-2">
            {groupedMatches.map(([day, list]) => (
              <div key={day} className="rounded-lg border border-slate-200 bg-slate-50 p-2.5">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-600">{day}</div>
                <div className="grid gap-1.5">
                  {list.map((m) => (
                    <Link key={m.id} to={`/matches/${m.id}`} className="rounded-md border border-slate-200 bg-white px-2.5 py-2 transition hover:border-sky-300">
                      <div className="flex flex-wrap items-center justify-between gap-1 text-xs text-slate-500">
                        <span className="font-semibold text-slate-700">R{m.round_number ?? "-"} - {m.status}</span>
                        <span>{formatDateTime(m.scheduled_at)}</span>
                      </div>
                      <div className="text-sm font-medium text-slate-900">
                        {resolveTeamName(m, "home")} vs {resolveTeamName(m, "away")}
                      </div>
                      <div className="text-xs text-slate-500">
                        Tournament: {m.tournament?.name || `#${m.tournament_id}`}
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
